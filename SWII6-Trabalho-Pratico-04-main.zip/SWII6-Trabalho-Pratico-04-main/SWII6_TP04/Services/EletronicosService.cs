﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Recognizers.Definitions;
using Newtonsoft.Json;
using SWII6_Models.Dtos;
using SWII6_Models.Models;
using SWII6_TP03.Controllers;
using System.Net;

namespace SWII6_TP04.Services
{
    public class EletronicoService : EletronicoServiceBase
    {
        public EletronicoService()
        {
            BaseURL = "http://localhost:5151";
        }
    }

    internal class eletronico
    {
    }
}
