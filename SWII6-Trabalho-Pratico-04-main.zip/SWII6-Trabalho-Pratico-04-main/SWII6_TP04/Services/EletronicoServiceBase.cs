﻿using Newtonsoft.Json;
using SWII6_TP03.Controllers;
using System.Net;

namespace SWII6_TP04.Services
{
    public class EletronicoServiceBase
    {
        private string baseURL;
        private object dto;

        public async Task<bool> Create(EletronicoCreateDTO dto)
        {
            var client = new HttpClient();

            var request = new HttpRequestMessage(HttpMethod.Post, $"{baseURL}/eletronicos");

            var content = JsonConvert.SerializeObject(dto);

            request.Content = new StringContent(content, null, "application/json");
            var response = await client.SendAsync(request);
            response.EnsureSuccessStatusCode();

            await response.Content.ReadAsStringAsync();

            return response.StatusCode == HttpStatusCode.Created;
        }

        public async Task<bool> Delete(int id)
        {
            var client = new HttpClient();

            var request = new HttpRequestMessage(HttpMethod.Delete, $"{baseURL}/eletronicos/{id}");


            var response = await client.SendAsync(request);
            response.EnsureSuccessStatusCode();

            await response.Content.ReadAsStringAsync();

            return response.StatusCode == HttpStatusCode.NoContent;
        }

        public async Task<eletronico> Get(int id)
        {
            var client = new HttpClient();

            var request = new HttpRequestMessage(HttpMethod.Get, $"{baseURL}/eletronicos/{id}");


            var response = await client.SendAsync(request);
            response.EnsureSuccessStatusCode();

            var eletronico = JsonConvert.DeserializeObject<eletronico>(await response.Content.ReadAsStringAsync());

            return eletronico;
        }

        public async Task<List<eletronico>> GetAllgma()
        {
            var client = new HttpClient();

            var request = new HttpRequestMessage(HttpMethod.Get, $"{baseURL}/eletronicos");

            var response = await client.SendAsync(request);
            response.EnsureSuccessStatusCode();

            var eletronicos = JsonConvert.DeserializeObject<List<eletronico>>(await response.Content.ReadAsStringAsync());

            return eletronicos;
        }

        public async Task<bool> Update(EletronicoCreateDTO)
        {
            var client = new HttpClient();

            var request = new HttpRequestMessage(HttpMethod.Put, $"{baseURL}/eletronicos/{dto.Id}");

            var content = JsonConvert.SerializeObject(dto);

            request.Content = new StringContent(content, null, "application/json");
            var response = await client.SendAsync(request);
            response.EnsureSuccessStatusCode();

            await response.Content.ReadAsStringAsync();

            return response.StatusCode == HttpStatusCode.NoContent;
        }
    }
}