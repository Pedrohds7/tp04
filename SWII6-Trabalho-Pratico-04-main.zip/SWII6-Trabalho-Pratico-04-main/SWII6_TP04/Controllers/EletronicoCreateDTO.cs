﻿namespace SWII6_TP03.Controllers
{
    public class EletronicoCreateDTO
    {
    }
}