﻿using Microsoft.AspNetCore.Mvc;
using SWII6_TP04.Services;
using SWII6_Models.Dtos;

namespace SWII6_TP03.Controllers;

public class EletronicoController : Controller
{
    private readonly EletronicoService _eletronicoService;

    public EletronicoController(EletronicoService EletronicoService)
    {
        _eletronicoService = EletronicoService;
    }

    public async Task<IActionResult> Index()
    {
        var eletronicos = await _eletronicoService.GetAll();
        return View(eletronicos);
    }

    public async Task<IActionResult> Details(int? id)
    {
        if (id == null)
            return NotFound();

        var eletronico = await _eletronicoService.Get((int)id);
        return View(eletronico);
    }


    public IActionResult Create()
    {
        return View();
    }

    // To protect from overposting attacks, enable the specific properties you want to bind to.
    // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(EletronicoCreateDTO eletronico)
    {
        if (ModelState.IsValid)
        {
            await _eletronicoService.Create(eletronico);
            return RedirectToAction(nameof(Index));
        }

        return View(eletronico);
    }

    // GET: eletronicos/Edit/5
    public async Task<IActionResult> Edit(int? id)
    {
        if (id == null)
            return NotFound();

        var eletronico = await _eletronicoService.Get((int)id);

        if (eletronico == null)
            return NotFound();

        return View(eletronico);
    }

    // To protect from overposting attacks, enable the specific properties you want to bind to.
    // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, EletronicoCreateDTO eletronico)
    {
        if (id != eletronico.Id)
        {
            return NotFound();
        }

        if (ModelState.IsValid)
        {
            await _eletronicoService.Update(eletronico);
            return RedirectToAction(nameof(Index));
        }
        return View(eletronico);
    }


    public async Task<IActionResult> Delete(int? id)
    {
        if (id == null)
            return NotFound();

        var eletronico = await _eletronicoService.Get((int)id);

        if (eletronico == null)
            return NotFound();

        return View(eletronico);
    }

    [HttpPost, ActionName("Delete")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        var eletronico = await _eletronicoService.Get(id);
        if (eletronico != null)
        {
            await _eletronicoService.Delete(eletronico.Id);
        }
        
        return RedirectToAction(nameof(Index));
    }
}
