﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SWII6_Models.Dtos;
using SWII6_Models.Utils;
using SWII6_TP03.Context;

namespace SWII6_API.Controllers
{
    [Route("eletronicos")]
    [ApiController]
    public class EletronicosController : ControllerBase
    {
        private readonly TpContext _context;

        public EletronicosController(TpContext context)
        {
            _context = context;
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> Get([FromRoute] int id)
        {
            if (id == null || _context.eletronicos == null)
                return NotFound();

            var eletronico = await _context.eletronicos.FirstOrDefaultAsync(m => m.Id == id);

            if (eletronico == null)
                return NotFound();

            return Ok(eletronico);
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var eletronicos = await _context.eletronicos.ToListAsync();

            if (eletronicos == null || eletronicos.Count <= 0)
                return NotFound();

            return Ok(eletronicos);
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] eletronicoCreateDTO dto)
        {
            if (ModelState.IsValid)
            {
                _context.Add(dto.toModel());
                var eletronico = await _context.SaveChangesAsync();
                return Created("", eletronico);
            }

            return BadRequest();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete([FromRoute] int id)
        {
            if (id == null || _context.eletronicos == null)
                return NotFound();

            var eletronico = await _context.eletronicos.FirstOrDefaultAsync(m => m.Id == id);

            if (eletronico == null)
                return NotFound();

            _context.eletronicos.Remove(eletronico);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update([FromRoute] int id, [FromBody] eletronicoUpdateDTO dto)
        {
            if (id == null || _context.eletronicos == null)
                return NotFound();

            var eletronico = await _context.eletronicos.FirstOrDefaultAsync(m => m.Id == id);

            if (eletronico == null)
                return NotFound();

            eletronico.toUpdateWithDto(dto);

            _context.eletronicos.Update(eletronico);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}
