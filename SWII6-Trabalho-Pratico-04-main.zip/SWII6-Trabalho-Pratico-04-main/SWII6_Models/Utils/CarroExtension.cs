﻿using SWII6_Models.Dtos;
using SWII6_Models.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SWII6_Models.Utils
{
    public static class eletronicoExtension
    {

        public static eletronico toModel(this eletronicoCreateDTO dto)
        {
            return new eletronico()
            {
                Id = 0,
                Marca = dto.Marca,
                Modelo = dto.Modelo,
                Eletronico = dto.Eletronico,
                Ano = dto.Ano
            };
        }

        public static eletronico toModel(this eletronicoUpdateDTO dto)
        {
            return new eletronico()
            {
                Id = dto.Id,
                Marca = dto.Marca,
                Modelo = dto.Modelo,
                Eletronico = dto.Eletronico,
                Ano = dto.Ano
            };
        }

        public static void toUpdateWithDto(this eletronico eletronico, eletronicoUpdateDTO dto)
        {
            eletronico.Modelo = dto.Modelo;
            eletronico.Eletronico = dto.Eletronico;
            eletronico.Marca = dto.Marca;
            eletronico.Ano = dto.Ano;
        }
    }
}
